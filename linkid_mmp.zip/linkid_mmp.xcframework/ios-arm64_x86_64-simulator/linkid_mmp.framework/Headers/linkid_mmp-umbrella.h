#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

//#import <linkid_mmp/linkid_mmp-Swift.h>


FOUNDATION_EXPORT double linkid_mmpVersionNumber;
FOUNDATION_EXPORT const unsigned char linkid_mmpVersionString[];

